exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  const ACCOUNT_SID = 'AC57c0158e862fc95fca70d3d5ed861b13';
  const AUTH_TOKEN  = '98b1c7fc6423acb5cce6c569754637f0';
  const FROM        = '+18039914457';

  let body;
  try { body = JSON.parse(event.body); }
  catch { return { statusCode: 400, body: 'Invalid JSON' }; }

  const { to, message } = body;
  if (!to || !message) return { statusCode: 400, body: 'Missing to or message' };

  const recipients = Array.isArray(to) ? to : [to];
  const results = [];

  for (const number of recipients) {
    const params = new URLSearchParams({ To: number, From: FROM, Body: message });
    const resp = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${ACCOUNT_SID}/Messages.json`,
      {
        method: 'POST',
        headers: {
          'Authorization': 'Basic ' + Buffer.from(`${ACCOUNT_SID}:${AUTH_TOKEN}`).toString('base64'),
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: params.toString()
      }
    );
    const data = await resp.json();
    results.push({ number, sid: data.sid, error: data.message });
  }

  const allOk = results.every(r => r.sid);
  return {
    statusCode: allOk ? 200 : 500,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(results)
  };
};
